//
//  ToDoListItem+CoreDataClass.swift
//  CoinFlip
//
//  Created by Tim Nguyen on 5/7/23.
//  Copyright © 2023 RADEFFFACTORY. All rights reserved.
//
//

import Foundation
import CoreData

@objc(ToDoListItem)
public class ToDoListItem: NSManagedObject {

}
