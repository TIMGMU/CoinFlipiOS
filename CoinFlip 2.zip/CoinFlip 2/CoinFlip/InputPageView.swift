//
//  InputPageView.swift
//  CoinFlip
//
//  Created by Tim Nguyen on 5/7/23.
//  Copyright © 2023 RADEFFFACTORY. All rights reserved.
//

import SwiftUI

struct InputPageView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct InputPageView_Previews: PreviewProvider {
    static var previews: some View {
        InputPageView()
    }
}
